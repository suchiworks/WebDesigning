<?php include "header.php" ?>


<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Booking</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Booking</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->


<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="d-flex py-5 px-4">
                    <i class="fa fa-certificate fa-3x text-primary flex-shrink-0"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">24/7 Services</h5>
                        <p> You can typically find taxi services available around the clock in popular tourist
                            destinations like Puri.</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="d-flex bg-light py-5 px-4">
                <i class="fas fa-user-cog fa-3x text-primary"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Professional Drivers</h5>
                        <p>To find professional drivers in Puri, India, for taxi services, you can employ various
                            strategies:</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="d-flex py-5 px-4">
                <i class="fas fa-tools fa-3x text-primary"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Best Prices</h5>
                        <p>Finding the best prices for taxi services in Puri, India, involves some research and
                            negotiation. Here are some tips to help you find competitive prices:</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->


<!-- Booking Start -->
<div class="container-fluid bg-secondary booking my-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="row gx-5">
            <div class="col-lg-6 py-5">
                <div class="py-2">
                    <h1 class="text-white mb-4">Taxi Booking Service in Puri</h1>
                    <p class="text-white mb-0">Experience seamless travel in the picturesque city of Puri with our
                        reliable and convenient taxi booking service. Whether you're a tourist exploring the beautiful
                        beaches and historical landmarks or a local resident in need of hassle-free transportation,
                        we've got you covered.</p><br>
                    <p class="text-white ">Why Choose Puri Taxi Booking Service:</p>
                    <ol class="text-white ">
                        <li>Easy Online Booking: Book your taxi with just a few clicks from the comfort of your home or
                            on the go using our user-friendly online platform.</li>
                        <li>Wide Range of Vehicles: Choose from our diverse fleet of well-maintained taxis, including
                            sedans, SUVs, and minivans, to suit your travel needs and preferences.</li>
                        <li>Wide Range of Vehicles: Choose from our diverse fleet of well-maintained taxis, including
                            sedans, SUVs, and minivans, to suit your travel needs and preferences.</li>
                    </ol>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="bg-primary h-100 d-flex flex-column justify-content-center text-center p-5 wow zoomIn"
                    data-wow-delay="0.6s">
                    <h1 class="text-white mb-4">Book a Taxi</h1>
                    <form>
                        <div class="row g-3">
                            <div class="col-12 col-sm-6">
                                <input type="text" class="form-control border-0" placeholder="Your Name"
                                    style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-6">
                                <input type="email" class="form-control border-0" placeholder="Your Email"
                                    style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-6">
                                <select class="form-select border-0" style="height: 55px;">
                                    <option selected>Select Services</option>
                                    <option value="1">Luxury Suv</option>
                                    <option value="2">Compact Sedans</option>
                                    <option value="3">MiniBus Taxi</option>
                                    <option value="3">Luxury Cabs</option>
                                </select>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="date" id="date1" data-target-input="nearest">
                                    <input type="text" class="form-control border-0 datetimepicker-input"
                                        placeholder="Date" data-target="#date1" data-toggle="datetimepicker"
                                        style="height: 55px;">
                                </div>
                            </div>
                            <div class="col-12">
                                <textarea class="form-control border-0" placeholder=" Request Message"></textarea>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-secondary w-100 py-3" type="submit">Book Now</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Booking End -->


<!-- Call To Action Start -->
<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-8 col-md-6">
                <h6 class="text-primary text-uppercase">// Call Us //</h6>
                <h1 class="mb-4">Have Any Pre Booking Question?</h1>
                <p class="mb-0">Yes, if you're planning to pre-book a taxi service in Puri or any other location, there
                    are several questions you might consider asking to ensure a smooth and satisfactory experience. Here
                    are some pre-booking questions you might find helpful:</p>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="bg-primary d-flex flex-column justify-content-center text-center h-100 p-4">
                    <h3 class="text-white mb-4"><i class="fa fa-phone-alt me-3"></i>+91-9337728538</h3>
                    <a href="" class="btn btn-secondary py-3 px-5">Contact Us<i class="fa fa-arrow-right ms-3"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Call To Action End -->


<?php include "footer.php" ?>


    

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn p-0" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Newsletter</h4>
                    <p>Where quality meets affordability. We understand the importance of a smooth and enjoyable journey
                        without the burden of excessive costs. That’s why we have meticulously crafted our offerings to
                        provide you with top-notch vehicles at minimum expense.</p>
                    <!-- <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-0 w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                        <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div> -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Opening Hours</h4>
                    <h6 class="text-light">Monday - Saturday:</h6>
                    <p class="mb-4">09.00 AM - 07.00 PM</p>
                    <!-- <h6 class="text-light">Saturday - Sunday:</h6>
                    <p class="mb-0">09.00 AM - 12.00 PM</p> -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Legal Terms</h4>
                    <a class="btn btn-link" href="terms&conditions">Terms & Conditions</a>
                    <a class="btn btn-link" href="refundpolicy">Refund Policy</a>
                    <a class="btn btn-link" href="returnpolicy">Return Policy</a>
                    <a class="btn btn-link" href="privacypolicy">Privacy Policy</a>
                    <!-- <a class="btn btn-link" href="">Vacuam Cleaning</a> -->
                </div>

                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Address</h4>
                    <p class="mb-2"><i class="bi bi-geo-alt-fill me-3"></i></i>Plot No-312,New Marine Drive Road
                        Baliapanda, Near Hotel Empires Infornt of Blue Lily Hotel Puri-752001</p>
                    <p class="mb-2"><i class="bi bi-telephone-fill me-3"></i></i>+91 9124625047</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>padmanabhatourtravels@gmail.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.instagram.com/saisamrattravels/"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.facebook.com/saisamrattoursandtravels?mibextid=LQQJ4d"><i
                                class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.youtube.com/@saisamrattoursandtravels"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.linkedin.com/404/"><i
                                class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="copy_rt">
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-8 text-center text-md-start mb-3 mb-md-0">
                            © <a class="border-bottom" href="#">2024 </a> .PADMANABHA TOUR & TRAVELS All Right Reserved.
                            Designed By
                            <span class="ft" style="color: black;">&nbsp;<a
                                    href="https://www.strivingsquad.com/">STRIVINGSQUAD PVT LTD</a></span>

                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            </a>
                        </div>
                        <div class="col-md-4 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <link rel="stylesheet" href="#">
    <a href="#" class="call" target="_blank">
        <i class="bi bi-telephone-fill"></i>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <a href="https://api.whatsapp.com/send?phone=51955081075&text=Hola%21%20Quisiera%20m%C3%A1s%20informaci%C3%B3n%20sobre%20Varela%202."
            class="float" target="_blank">
            <i class="fa fa-whatsapp my-float"></i>
        </a>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>
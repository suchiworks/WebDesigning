<?php include "header.php" ?>


<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Contact</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->


<!-- Contact Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="text-primary text-uppercase">// Contact Us //</h6>
            <h1 class="mb-5">Contact For Any Query</h1>
        </div>
        <div class="row g-4">
            <div class="col-12">
                <div class="row gy-4">
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">// Booking //</h5>
                            <p class="m-0">
                            <i class="bi bi-envelope-open-fill text-primary me-2"></i>padmanabhatourtravels@gmail.com
                            
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">// General //</h5>
                            <p class="m-0"><i class="bi bi-envelope-open-fill text-primary me-2"></i>padmanabhatourtravels@gmail.com
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-light d-flex flex-column justify-content-center p-4">
                            <h5 class="text-uppercase">// Technical //</h5>
                            <p class="m-0"><i class="bi bi-envelope-open-fill text-primary me-2"></i>padmanabhatourtravels@gmail.com
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7508.26998150358!2d85.79267119129268!3d19.79187307626263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a19c43aa29b8a03%3A0xb516a8ea8f5ba40b!2sBlue%20Lily%20Beach%20Resort!5e0!3m2!1sen!2sin!4v1711965170466!5m2!1sen!2sin"
                    width="100%" height="525" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>


            <!-- contact form -->
            <div class="col-md-6">
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <h2 class="mb-4" style="text-align: center;">Contact Us For Any Query</a></h2>
                    <br>
                    <form action="https://formspree.io/f/mrgnollq" method="POST" class="form">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="name" placeholder="Your Name">
                                    <label for="name">First Name</label>
                                </div>
                            </div>
    
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="name" placeholder="Last Name">
                                    <label for="name">Last Name</label>
                                </div>
                            </div>
                            

                            <input type="hidden" name="access_key" value="8cecda39-bda1-4d20-beb4-c8a6938e83d8">
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="email" class="form-control" name="email" placeholder="Your Email">
                                    <label for="email">Email</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="phone" placeholder="phone">
                                    <label for="subject">Phone</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" style="height: 142px;"
                                        placeholder="Leave a message here" name="message"
                                        style="height: 100px"></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- contact form end -->
            
        </div>
    </div>
</div>
<!-- Contact End -->


<?php include "footer.php" ?>
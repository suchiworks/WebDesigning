<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Taxi Service In Puri-Chandaka</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@600;700&family=Ubuntu:wght@400;500&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <!-- <div class="container-fluid bg-light p-0">
        <div class="row gx-0 d-none d-lg-flex">
            <div class="col-lg-7 px-5 text-start">
                <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                    <small class="fa fa-map-marker-alt text-primary me-2"></small>
                    <small>123 Street, New York, USA</small>
                </div>
                <div class="h-100 d-inline-flex align-items-center py-3">
                    <small class="far fa-clock text-primary me-2"></small>
                    <small>Mon - Fri : 09.00 AM - 09.00 PM</small>
                </div>
            </div>
            <div class="col-lg-5 px-5 text-end">
                <div class="h-100 d-inline-flex align-items-center py-3 me-4">
                    <small class="fa fa-phone-alt text-primary me-2"></small>
                    <small>+012 345 6789</small>
                </div>
                <div class="h-100 d-inline-flex align-items-center">
                    <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-1" href=""><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-sm-square bg-white text-primary me-0" href=""><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"></i>Padmanabha Tour & Travels</h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link active">Home</a>
                <a href="about.php" class="nav-item nav-link">About</a>
                <a href="cars.php" class="nav-item nav-link">Cars</a>
                <a href="tours.php" class="nav-item nav-link">Tours</a>
                <!-- <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu fade-up m-0">
                        <a href="booking.php" class="dropdown-item">Booking</a>
                        <a href="team.php" class="dropdown-item">Technicians</a>
                        <a href="testimonial.php" class="dropdown-item">Testimonial</a>
                        <a href="404.php" class="dropdown-item">404 Page</a>
                    </div>
                </div> -->
                <a href="contact.php" class="nav-item nav-link">Booking</a>
            </div>
            <a href="" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">Contact<i
                    class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->


    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/tour6.jpg);">
        <div class="container-fluid page-header-inner py-5">
            <div class="container text-center">
                <h1 class="display-3 text-white mb-3 animated slideInDown">Tours</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center text-uppercase">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Tours</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Tours Start -->

    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="text-primary text-uppercase">// Tours Packages //</h6>
                <h1 class="mb-5"></h1>
            </div>
        </div>
    </div>

    <section class="kn-item">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <img src="img/tour6.jpg" width="100%" alt="image">


                </div>
                <div class="col-lg-4">
                </div>
                <!-- inner -->
                <div>
                    <h4>Itenary Details:</h4><br>

                    <p>Chandaka is a region located near Bhubaneswar, the capital city of the Indian state of Odisha. It
                        is known for its rich biodiversity, wildlife sanctuary, and eco-tourism opportunities. Here's an
                        itinerary for exploring Chandaka and its attractions:</p>


                    <h5>Day 1: Arrival in Chandaka</h5><br>
                    <ol>
                        <li>
                            <p><strong>Morning</strong>:</p>
                            <ul>
                                <li>Arrive in Chandaka, either by road or from your accommodation in Bhubaneswar, which
                                    is around 20 kilometers away.</li>
                                <li>Check into your accommodation, which may include eco-resorts or guesthouses located
                                    in or around the Chandaka Wildlife Sanctuary.</li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Late Morning/Afternoon</strong>:</p>
                            <ul>
                                <li>Begin your exploration of Chandaka by visiting the Chandaka-Dampara Wildlife
                                    Sanctuary. This sanctuary is home to a diverse range of flora and fauna, including
                                    elephants, deer, wild boars, and various species of birds.</li>
                                <li>Enjoy a guided nature walk or jungle safari within the sanctuary, accompanied by
                                    trained naturalists who can provide insights into the region's ecology and wildlife.
                                </li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Evening</strong>:</p>
                            <ul>
                                <li>Return to your accommodation and relax amidst the tranquil surroundings of Chandaka.
                                </li>
                                <li>Enjoy a delicious dinner featuring local cuisine, which may include dishes prepared
                                    with locally sourced ingredients.</li>
                            </ul>
                        </li>
                    </ol>

                    <h5>Day 2: Exploring Chandaka</h5><br>

                    <ol>
                        <li>
                            <p><strong>Morning</strong>:</p>
                            <ul>
                                <li>Embark on an early morning nature trail or birdwatching session within the Chandaka
                                    Wildlife Sanctuary. The early hours offer the best chance to spot wildlife and
                                    observe bird species in their natural habitat.</li>
                                <li>Visit the Bhuasuni Temple, an ancient shrine located within the sanctuary premises.
                                    This temple is dedicated to Goddess Bhuasuni and is revered by locals.</li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Late Morning/Afternoon</strong>:</p>
                            <ul>
                                <li>Explore the Kanjia Lake, located adjacent to the Chandaka Wildlife Sanctuary. This
                                    picturesque lake is a haven for birdwatchers and is home to migratory birds during
                                    the winter months.</li>
                                <li>Enjoy boating or paddle boating on the lake, soaking in the scenic beauty of the
                                    surrounding forested hills.</li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Evening</strong>:</p>
                            <ul>
                                <li>Spend the evening relaxing at your accommodation or indulging in leisure activities
                                    offered by the eco-resort or guesthouse.</li>
                                <li>Take a nature walk around the property, admiring the lush greenery and listening to
                                    the sounds of the forest.</li>
                            </ul>
                        </li>
                    </ol>

                    <h5>Day 3: Departure from Chandaka</h5><br>

                    <ol>
                        <li>
                            <p><strong>Morning</strong>:</p>
                            <ul>
                                <li>If time permits, you can engage in any remaining activities or explore nearby
                                    attractions such as the Nandankanan Zoological Park, which is located in close
                                    proximity to Chandaka.</li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Late Morning/Afternoon</strong>:</p>
                            <ul>
                                <li>Check out from your accommodation and depart from Chandaka, either by road or
                                    returning to your onward destination in Bhubaneswar.</li>
                            </ul>
                        </li><br>
                        <li>
                            <p><strong>Departure</strong>:</p>
                            <ul>
                                <li>Depending on your onward travel plans, you can proceed to your next destination or
                                    depart for your journey back home, carrying cherished memories of your time spent
                                    amidst nature in Chandaka.</li>
                            </ul>
                        </li>
                    </ol>

                </div>
            </div>
        </div>
    </section>

    <!-- Tours End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn p-0" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Newsletter</h4>
                    <p>Where quality meets affordability. We understand the importance of a smooth and enjoyable journey
                        without the burden of excessive costs. That’s why we have meticulously crafted our offerings to
                        provide you with top-notch vehicles at minimum expense.</p>
                    <!-- <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-0 w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                        <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div> -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Opening Hours</h4>
                    <h6 class="text-light">Monday - Saturday:</h6>
                    <p class="mb-4">09.00 AM - 07.00 PM</p>
                    <!-- <h6 class="text-light">Saturday - Sunday:</h6>
                    <p class="mb-0">09.00 AM - 12.00 PM</p> -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Legal Terms</h4>
                    <a class="btn btn-link" href="terms&conditions.php">Terms & Conditions</a>
                    <a class="btn btn-link" href="refundpolicy.php">Refund Policy</a>
                    <a class="btn btn-link" href="returnpolicy.php">Return Policy</a>
                    <a class="btn btn-link" href="privacypolicy.php">Privacy Policy</a>
                    <!-- <a class="btn btn-link" href="">Vacuam Cleaning</a> -->
                </div>

                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Address</h4>
                    <p class="mb-2"><i class="bi bi-geo-alt-fill me-3"></i></i>Plot No-312,New Marine Drive Road
                        Baliapanda, Near Hotel Empires Infornt of Blue Lily Hotel Puri-752001</p>
                    <p class="mb-2"><i class="bi bi-telephone-fill me-3"></i></i>+91-9337728538</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>om.Puri@durenehotels.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.instagram.com/saisamrattravels/"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.facebook.com/saisamrattoursandtravels?mibextid=LQQJ4d"><i
                                class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social"
                            href="https://www.youtube.com/@saisamrattoursandtravels"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.linkedin.com/404/"><i
                                class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="copy_rt">
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-8 text-center text-md-start mb-3 mb-md-0">
                            © <a class="border-bottom" href="#">2024 </a> .PADMANABHA TOUR & TRAVELS All Right Reserved.
                            Designed By
                            <span class="ft" style="color: black;">&nbsp;<a
                                    href="https://www.strivingsquad.com/">STRIVINGSQUAD PVT LTD</a></span>

                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            </a>
                        </div>
                        <div class="col-md-4 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
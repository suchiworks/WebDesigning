<?php include "header.php" ?>


<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/tour1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Tours</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Tours</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->

<!-- Tours Start -->

<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="text-center">
            <h6 class="text-primary text-uppercase">// Tours Packages //</h6>
            <h1 class="mb-5">Explore Our Places</h1>
        </div>
    </div>
</div>

<section class="properties">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="konark.php"><img src="img/tour1.jpg" width="100%" alt="image"></a>
                    <span class="category">Konark</span>

                    <!-- <h5><a href="#">Destination Covered: Temple Tour</a></h5> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="konark.php">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="puri.php"><img src="img/tour2.jpg" width="100%" alt="image"></a>
                    <span class="category">Puri</span>

                    <!-- <h4><a href="#">26 Old Street Miami, OR 38540</a></h4> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="puri.php">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="khandagiri.php"><img src="img/tour3.jpg" width="100%" alt="image"></a>
                    <span class="category">Khandagiri</span>

                    <!-- <h4><a href="#">26 Old Street Miami, OR 38540</a></h4> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="khandagiri.php">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="dhauligiri.php"><img src="img/tour4.jpg" width="100%" alt="image"></a>
                    <span class="category">Dhauligiri</span>

                    <!-- <h4><a href="#">26 Old Street Miami, OR 38540</a></h4> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="dhauligiri.php">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="lingaraj.php"><img src="img/tour5.jpg" width="100%" alt="image"></a>
                    <span class="category">Lingraj Temple</span>

                    <!-- <h4><a href="#">26 Old Street Miami, OR 38540</a></h4> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="lingaraj.php">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="item1">
                    <a href="chandaka.php"><img src="img/tour6.jpg" width="100%" alt="image"></a>
                    <span class="category">Chandaka</span>

                    <!-- <h4><a href="#">26 Old Street Miami, OR 38540</a></h4> -->
                    <ul>
                        <li> Temple Tour :<span> 04 Days / 03 Night</span></li>
                    </ul>
                    <div class="main-button">
                        <a href="chandaka.php">More Details</a>
                    </div>
                </div>
            </div>


        </div>
    </div>
</section>

<!-- Tours End -->

<?php include "footer.php" ?>
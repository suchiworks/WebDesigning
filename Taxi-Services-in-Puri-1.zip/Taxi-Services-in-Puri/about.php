<?php include "header.php" ?>



<!-- Page Header Start -->
<div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-1.jpg);">
    <div class="container-fluid page-header-inner py-5">
        <div class="container text-center">
            <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header End -->


<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="d-flex py-5 px-4">
                    <i class="fa fa-certificate fa-3x text-primary flex-shrink-0"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">24/7 Services</h5>
                        <p> You can typically find taxi services available around the clock in popular tourist
                            destinations like Puri.</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="d-flex bg-light py-5 px-4">
                    <i class="fas fa-user-cog fa-3x text-primary"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Professional Drivers</h5>
                        <p>To find professional drivers in Puri, India, for taxi services, you can employ various
                            strategies:</p>

                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="d-flex py-5 px-4">
                    <i class="fas fa-tools fa-3x text-primary"></i>
                    <div class="ps-4">
                        <h5 class="mb-3">Best Prices</h5>
                        <p>Finding the best prices for taxi services in Puri, India, involves some research and
                            negotiation. Here are some tips to help you find competitive prices:</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->


<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 pt-4" style="min-height: 400px;">
                <div class="position-relative h-100 wow fadeIn" data-wow-delay="0.1s">
                    <img class="position-absolute img-fluid w-100 h-100" src="img/about.jpg" style="object-fit: cover;"
                        alt="">

                </div>
            </div>
            <div class="col-lg-6">
                <h6 class="text-primary text-uppercase">// About Us //</h6>
                <h2 class="mb-4"><span class="text-primary">Best Taxi Service</span> in Puri</h2>
                <p class="mb-4">At Best Taxi Service, we pride ourselves on providing unparalleled transportation
                    solutions
                    tailored to your needs. Whether you're exploring the vibrant streets of Puri, heading to the
                    airport, or embarking on a scenic tour, our fleet of modern and well-maintained vehicles is at
                    your service.
                </p>

                <ol>
                    <li>Reliable and Professional Drivers: Our team of experienced and courteous drivers is dedicated to
                        ensuring a safe and enjoyable journey for every passenger.</li><br>

                    <li>Comfortable and Clean Vehicles: Travel in style and comfort with our spacious and meticulously
                        cleaned taxis, equipped with modern amenities for your convenience.</li><br>

                    <li>24/7 Availability: Whether it's day or night, rain or shine, we're here to provide reliable
                        transportation whenever and wherever you need it.</li><br>

                    <li>Competitive Rates: Enjoy affordable and transparent pricing with no hidden fees, ensuring
                        exceptional value for your money.</li>
                </ol>


                <!-- <div class="row g-4 mb-3 ">
                        <div class="col-12 wow fadeIn" data-wow-delay="0.1s">
                            <div class="d-flex">
                                <div class="bg-light d-flex flex-shrink-0 align-items-center justify-content-center mt-1" style="width: 45px; height: 45px;">
                                    <span class="fw-bold text-secondary">01</span>
                                </div>
                                <div class="ps-3">
                                    <h6>Professional & Expert</h6>
                                    <span>This concise statement highlights professionalism and expertise while emphasizing the excellence of your establishment in Puri. It suggests that your place is the top choice for individuals seeking professional service and expert assistance.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeIn" data-wow-delay="0.3s">
                            <div class="d-flex">
                                <div class="bg-light d-flex flex-shrink-0 align-items-center justify-content-center mt-1" style="width: 45px; height: 45px;">
                                    <span class="fw-bold text-secondary">02</span>
                                </div>
                                <div class="ps-3">
                                    <h6>Quality Servicing Center</h6>
                                    <span>"Quality Servicing Center: Your Premier Destination in Puri"</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 wow fadeIn" data-wow-delay="0.5s">
                            <div class="d-flex">
                                <div class="bg-light d-flex flex-shrink-0 align-items-center justify-content-center mt-1" style="width: 45px; height: 45px;">
                                    <span class="fw-bold text-secondary">03</span>
                                </div>
                                <div class="ps-3">
                                    <h6>Awards Winning Workers</h6>
                                    <ul>
                                        <li>ExcellenceTaxis Puri</li>
                                        <li>TopTierTransit Puri</li>
                                        <li>ApexCabs Puri</li>
                                        
                                  </ul>
                                </div>
                            </div>
                        </div>
                    </div> -->
                <!-- <a href="" class="btn btn-primary py-3 px-5">Read More<i class="fa fa-arrow-right ms-3"></i></a> -->
            </div>
        </div>
    </div>
</div>
<!-- About End -->


<?php include "footer.php" ?>
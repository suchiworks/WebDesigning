<?php include "header.php" ?>

<!-- banner -->
<div class="main-banner">
  <div class="owl-carousel owl-banner">
    <div class="item item-1">
      <div class="header-text">
        <h1 class="text-center text-light"> Welcome To Winning Wavez</h1>
        <h4 class="text-center text-light" style="margin-top:20px;margin-bottom:20px">Scope Of Skills In Digital
        </h4>
        <p class="text-center"><!--Empowering students through digital skills, the path to self-independence unfolds. By
          embracing online
          learning, students equip themselves with valuable tools for the digital era. Harnessing these skills, they
          embark on entrepreneurial journeys, establishing businesses online. This endeavor not only enhances financial
          autonomy but also nurtures a mindset of innovation and adaptability. -->
          Empowering students through digital skills, the path to self-independence unfolds. By
          embracing online
          learning, students equip themselves with valuable tools for the digital era. Harnessing these skills, they
          embark on entrepreneurial journeys, establishing businesses online
        </p>
      </div>
    </div>
    <div class="item item-2">

      <div class="header-text">
        <h1 class="text-center text-light"> Welcome To Winning Wavez</h1>
        <h4 class="text-center text-light my-2">Scope Of Skills In Digital
        </h4>
        <p class="text-center">Empowering students through digital skills, the path to self-independence unfolds. By
          embracing online
          learning, students equip themselves with valuable tools for the digital era. Harnessing these skills, they
          embark on entrepreneurial journeys, establishing businesses online.
        </p>
      </div>
    </div>
    <!-- <div class="item item-3">
        <div class="header-text">
          <span class="category">Miami, <em>South Florida</em></span>
          <h2>Act Now!<br>Get the highest level penthouse</h2>
        </div>
      </div> -->
  </div>
</div>
<!-- banner end -->


<!--2nd content -->
<div class="container pt-6 px-5">
  <div class="text-center mx-auto mb-5" style="max-width: 600px;">
    <h1 class="display-5 mb-0 mt-5" style="font-size: 40px;
    font-weight: 700;">What We Provide</h1>
    <hr class="w-25 mx-auto bg-primary">
  </div>
</div>

<!-- <div class="row g-5">
    <div class="col-lg-4 col-md-6">
      <div class="service-item bg-light text-center px-5">
        <div class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
          style="width: 50px; height: 50px;">
          <i class="fa fa-user fa-2x"></i>
        </div>
        <h3 class="mb-3">Access Anywhere</h3>
        <p class="mb-0">Internet's ubiquity transforms every space into a classroom, letting learning accompany you
          wherever
          life leads.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="service-item bg-light text-center px-5">
        <div class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
          style="width: 50px; height: 50px;">
          <i class="fa-solid fa-timeline fa-2x"></i>
        </div>
        <h3 class="mb-3">Learn At Your Time</h3>
        <p class="mb-0">All our courses are online, enabling flexible learning at your convenience,<br> tailored to
          your
          schedule.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-6">
      <div class="service-item bg-light text-center px-5">
        <div class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
          style="width: 50px; height: 50px;">
          <i class="fa-solid fa-book fa-2x"></i>
        </div>
        <h3 class="mb-3">Huge Course Library</h3>
        <p class="mb-0">Explore our computer courses library, featuring a diverse range from fundamental basics to
          advanced
          skills.</p>
      </div>
    </div>
  </div> -->

<!--2nd content end -->

<!-- owl carousel start -->
<div class="section7">
  <div class="container px-5">

    <div class="div8 container ">
      <div class="owl-carousel owl-theme car ">
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa fa-user fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Access Anywhere</h3>
            <p class="mb-0">Internet's ubiquity transforms every space into a classroom, letting learning accompany you
              wherever
              life leads.</p>
          </div>
        </div>
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa-solid fa-timeline fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Learn At Your Time</h3>
            <p class="mb-0">All our courses are online, enabling flexible learning at your convenience,<br> tailored to
              your
              schedule.</p>
          </div>
        </div>
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa-solid fa-book fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Huge Course Library</h3>
            <p class="mb-0">Explore our computer courses library, featuring a diverse range from fundamental basics to
              advanced
              skills.</p>
          </div>
        </div>
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa fa-user fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Access Anywhere</h3>
            <p class="mb-0">Internet's ubiquity transforms every space into a classroom, letting learning accompany you
              wherever
              life leads.</p>
          </div>
        </div>
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa-solid fa-timeline fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Learn At Your Time</h3>
            <p class="mb-0">All our courses are online, enabling flexible learning at your convenience,<br> tailored to
              your
              schedule.</p>
          </div>
        </div>
        <div class="post-slide">
          <div class="service-item bg-light text-center px-4">
            <div
              class="d-flex align-items-center justify-content-center bg-primary text-white rounded-circle mx-auto mb-4"
              style="width: 50px; height: 50px;">
              <i class="fa-solid fa-book fa-2x" style="font-size:1em"></i>
            </div>
            <h3 class="mb-3">Huge Course Library</h3>
            <p class="mb-0">Explore our computer courses library, featuring a diverse range from fundamental basics to
              advanced
              skills.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- owl carousel end -->


<!-- About Start -->

<!-- <div class="text-center mx-auto mb-5" style="max-width: 600px;">
      <h1 class="display-5 mb-0 mt-5" style="font-size: 40px; font-weight: 700;">About Winning Wavez</h1>
      <hr class="w-25 mx-auto bg-primary">
    </div> -->

<!-- 3rd  -->
<!-- <div class="featured section">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="left-image">
              <img src="assets/images/featured1.jpg" height="400px" width="367px" alt="">
              <a href="property-details.html"><img src="assets/images/featured-icon.png" alt=""
                  style="max-width: 60px; padding: 0px;"></a>
            </div>
          </div>
          <div class="col-lg-8">
            <div class="section-heading">
              <h6>| Featured</h6>
              <h2>About Winning Wavez</h2>

            </div>
            <div class="accordion" id="accordionExample">
              <div class="accordion-item">

                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"
                  data-bs-parent="#accordionExample">
                  <div class="accordion-body">
                    <p> WinningWavez is an e-learning platform. We are a company with values for life, envisioning a
                      future
                      and a mission of growth. We believe that each and everyone on the earth is blessed with equal
                      potential, and so they must get the equal opportunity to grow as well.
                      <br><br>

                      We are a company with values for life, vision for a future and a mission of growth. We believe
                      that
                      each and everyone on the earth is blessed with equal potential and so they must get the equal
                      opportunity to grow as well.

                      We believe in collaboration over competition and we are working towards creating this supporting
                      environment with our values for life. Because we believe that’s how we can create this country
                      with
                      value where everyone helps everyone and contribute to the overall growth of the nation by
                      growing
                      themselves.
                    </p>
                  </div>
                </div>
                <div class="icon-button">
                  <a href="about-us"><i class="fa fa-user"></i>View More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div> -->
<!-- 3rd end -->




<!-- clk section -->
<!-- <div class="text-center mx-auto mb-5" style="max-width: 600px;">
        <h1 class="display-5 mb-0 mt-5">Latest Featured Packages</h1>
        <hr class="w-25 mx-auto bg-primary">
      </div>
      <div class="section best-deal">


        <div class="container">
          <div class="row">
            <div class="col-lg-4">
              <div class="section-heading">
              </div>
            </div>
            <div class="col-lg-12">
              <div class="tabs-content">
                <div class="row">
                  <div class="nav-wrapper ">
                    <ul class="nav nav-tabs" role="tablist">

                      <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="appartment-tab" data-bs-toggle="tab"
                          data-bs-target="#appartment" type="button" role="tab" aria-controls="appartment"
                          aria-selected="true">Pre Win</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="villa-tab" data-bs-toggle="tab" data-bs-target="#villa"
                          type="button" role="tab" aria-controls="villa" aria-selected="false">Win Lite</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="penthouse-tab" data-bs-toggle="tab" data-bs-target="#penthouse"
                          type="button" role="tab" aria-controls="penthouse" aria-selected="false">Ultra Win</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="ultra-tab" data-bs-toggle="tab" data-bs-target="#ultra"
                          type="button" role="tab" aria-controls="ultra" aria-selected="false">Win Master</button>
                      </li>

                    </ul>
                  </div>
                  <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="appartment" role="tabpanel"
                      aria-labelledby="appartment-tab">
                      <div class="row">
                        <div class="col-lg-3">
                          <div class="info-table">
                            <ul>
                              <li>3 Courses Included <span></span></li>
                              <li>Lifetime Access <span></span></li>
                              <li>Easy to Understand <span></span></li>
                              <li>Master the art of Presentations <span></span></li>
                              <li>Techniques to Craft Captivating <span></span></li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <img src="assets/images/pre-win.jpg" width="100%" alt="image">
                        </div>
                        <div class="col-lg-3">
                          <h4>What you'll learn</h4>
                          <p>Pre-win packages are comprehensive bundles of configurations, dependencies, and scripts
                            meticulously crafted to streamline the deployment process for specific applications. Their
                            primary feature lies in their ability to condense all necessary components into a
                            singular, easy-to-deploy package, ensuring consistency across different environments while
                            minimizing deployment errors.

                          </p>
                          <p class="fees">Course Fees: <span> ₹ 999</span></p>
                          <div class="icon-button">
                            <a href="login-and-register.php"><i class="fa fa-user"></i>View More</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="villa" role="tabpanel" aria-labelledby="villa-tab">
                      <div class="row">
                        <div class="col-lg-3">
                          <div class="info-table">
                            <ul>
                              <li>5 Courses Included <span></span></li>
                              <li>Lifetime Access <span></span></li>
                              <li>Easy to Understand <span></span></li>
                              <li>Master the art of Presentations <span></span></li>
                              <li>Techniques to Craft Captivating <span></span></li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <img src="assets/images/win-lite.jpg" width="100%" alt="image">
                        </div>
                        <div class="col-lg-3">
                          <h4>What you'll learn</h4>
                          <p>Win Lite packages are specialized bundles of configurations, dependencies, and scripts
                            tailored to streamline the deployment process for specific applications in Windows
                            environments. These packages are characterized by their lightweight nature, focusing on
                            essential components to minimize resource usage and optimize performance. The key feature
                            of Win Lite packages is their ability to provide a lean and efficient deployment solution,

                          </p>
                          <p class="fees">Course Fees: <span> ₹ 2399</span></p>
                          <div class="icon-button">
                            <a href="login-and-register.php"><i class="fa fa-user"></i>View More</a>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="penthouse" role="tabpanel" aria-labelledby="penthouse-tab">
                      <div class="row">
                        <div class="col-lg-3">
                          <div class="info-table">
                            <ul>
                              <li>7 Courses Included <span></span></li>
                              <li>Lifetime Access <span></span></li>
                              <li>Easy to Understand <span></span></li>
                              <li>Master the art of Presentations <span></span></li>
                              <li>Techniques to Craft Captivating <span></span></li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <img src="assets/images/ultra-win.jpg" width="100%" alt="">
                        </div>
                        <div class="col-lg-3">
                          <div class="property-info">
                            <h4>What you'll learn</h4>
                            <p>Ultra Win packages represent the epitome of comprehensive deployment solutions for
                              Windows environments, offering a wealth of features to optimize performance,
                              reliability, and efficiency. These packages are characterized by their robustness and
                              completeness, encompassing a wide array of configurations, dependencies, and scripts
                              meticulously tailored to ensure seamless deployment experiences.

                            </p>
                            <p class="fees">Course Fees: <span> ₹ 4999</span></p>
                            <div class="icon-button">
                              <a href="login-and-register.php"><i class="fa fa-user"></i>View More</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="ultra" role="tabpanel" aria-labelledby="ultra-tab">
                      <div class="row">
                        <div class="col-lg-3">
                          <div class="info-table">
                            <ul>
                              <li>10 Courses Included <span></span></li>
                              <li>Lifetime Access <span></span></li>
                              <li>Easy to Understand <span></span></li>
                              <li>Master the art of Presentations <span></span></li>
                              <li>Techniques to Craft Captivating <span></span></li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <img src="assets/images/win-master.jpg" width="100%" alt="image">
                        </div>
                        <div class="col-lg-3">
                          <h4>What you'll learn</h4>
                          <p>
                            Win Master packages represent a pinnacle in Windows deployment solutions, offering a
                            comprehensive suite of features designed to streamline the deployment process and optimize
                            system performance. These packages are distinguished by their versatility and
                            completeness, encompassing a wide range of configurations, dependencies, and scripts
                            tailored to ensure seamless deployment experiences across diverse environments.

                          </p>
                          <p class="fees">Course Fees: <span> ₹ 7999</span></p>
                          <div class="icon-button">
                            <a href="login-and-register.php"><i class="fa fa-user"></i>View More</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->
<!-- clk section end -->

<!-- courses -->
<div class="properties section">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 offset-lg-4">
        <div class="section-heading text-center">
          <h6>| Courses</h6>
          <h2>Our Packages</h2>
          <hr class="w-25 mx-auto bg-primary">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-6">
        <div class="item">
          <div class="post-img"> <a href="courses"><img src="assets/images/pre-win.jpg" alt=""></a>
          </div>

          <span class="category text-center">Pre Win</span>
          <h4 class="course-catagory"><a href="#">Course Fees:</a><span>₹ 999</span></h4>
          <div class="main-button">
            <a href="contact">Enroll Now</a>
          </div>
        </div>
        <!-- <div class="post-slide">
          <div class="post-img">
            <img src="assets/images/pre-win.jpg" alt="">
          </div>
          <div class="post-content">
            <h3 class="post-title">
              <a href="#">Pre Win</a>
            </h3>
            <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Aperiam consectetur cumque
              dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
            <div class="main-button">
              <a href="contact">Enroll Now</a>
            </div>
          </div>
        </div> -->
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="item">
          <a href="courses"><img src="assets/images/win-lite.jpg" alt=""></a>
          <span class="category">Win Lite</span>
          <h4 class="course-catagory"><a href="#">Course Fees:</a><span>₹ 2399</span></h4>

          <div class="main-button">
            <a href="contact">Enroll Now</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="item">
          <a href="courses"><img src="assets/images/ultra-win.jpg" alt=""></a>
          <span class="category">Ultra Win</span>
          <h4 class="course-catagory"><a href="#">Course Fees:</a><span>₹ 4999</span></h4>

          <div class="main-button">
            <a href="contact">Enroll Now</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="item">
          <a href="courses"><img src="assets/images/win-master.jpg" alt=""></a>
          <span class="category">Win Master</span>
          <h4 class="course-catagory"><a href="#">Course Fees:</a><span>₹ 7999</span></h4>

          <div class="main-button">
            <a href="contact">Enroll Now</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- courses end -->

<!-- <div class="col-lg-4 col-md-6">
              <div class="item">
                <a href="ms-excel.php"><img src="assets/images/course5.jpg" alt=""></a>
                <span class="category">Ms Excel</span>
                <h6>₹ 2399</h6>
                <h4><a href="ms-excel.php">34 Beach Street Miami, OR 42680</a></h4>
                <ul>
                  <li>Bedrooms: <span>4</span></li>
                  <li>Bathrooms: <span>4</span></li>
                  <li>Area: <span>180m2</span></li>
                  <li>Floor: <span>38th</span></li>
                  <li>Parking: <span>2 cars</span></li>
                </ul>
                <div class="main-button">
                  <a href="ms-excel.php">Schedule a visit</a>
                </div>
              </div>
            </div> -->
<!-- <div class="col-lg-4 col-md-6">
              <div class="item">
                <a href="instagram-grow.php"><img src="assets/images/course6.jpg" alt=""></a>
                <span class="category">instagram Grow</span>
                <h6>$450.000</h6>
                <h4><a href="instagram-grow.php">22 New Street Portland, OR 16540</a></h4>
                <ul>
                  <li>Bedrooms: <span>3</span></li>
                  <li>Bathrooms: <span>2</span></li>
                  <li>Area: <span>165m2</span></li>
                  <li>Floor: <span>26th</span></li>
                  <li>Parking: <span>3 cars</span></li>
                </ul>
                <div class="main-button">
                  <a href="instagram-grow.php">Schedule a visit</a>
                </div>
              </div>
            </div> -->
<!-- </div>
  </div>
</div> -->

<!-- <div class="contact section">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 offset-lg-4">
            <div class="section-heading text-center">
              <h6>| Contact Us</h6>
              <h2>Get In Touch With Our Agents</h2>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="contact-content">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <div id="map">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12469.776493332698!2d-80.14036379941481!3d25.907788681148624!2m3!1f357.26927939317244!2f20.870722720054623!3f0!3m2!1i1024!2i768!4f35!3m3!1m2!1s0x88d9add4b4ac788f%3A0xe77469d09480fcdb!2sSunny%20Isles%20Beach!5e1!3m2!1sen!2sth!4v1642869952544!5m2!1sen!2sth"
                width="100%" height="500px" frameborder="0"
                style="border:0; border-radius: 10px; box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.15);"
                allowfullscreen=""></iframe>
            </div>
            <div class="row">
              <div class="col-lg-6">
                <div class="item phone">
                  <img src="assets/images/phone-icon.png" alt="" style="max-width: 52px;">
                  <h6>010-020-0340<br><span>Phone Number</span></h6>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="item email">
                  <img src="assets/images/email-icon.png" alt="" style="max-width: 52px;">
                  <h6>info@villa.co<br><span>Business Email</span></h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5">
            <form id="contact-form" action="" method="post">
              <div class="row">
                <div class="col-lg-12">
                  <fieldset>
                    <label for="name">Full Name</label>
                    <input type="name" name="name" id="name" placeholder="Your Name..." autocomplete="on" required>
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <label for="email">Email Address</label>
                    <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..."
                      required="">
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <label for="subject">Subject</label>
                    <input type="subject" name="subject" id="subject" placeholder="Subject..." autocomplete="on">
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <label for="message">Message</label>
                    <textarea name="message" id="message" placeholder="Your Message"></textarea>
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <button type="submit" id="form-submit" class="orange-button">Send Message</button>
                  </fieldset>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div> -->


<!-- faq -->

<div class="text-center mx-auto mb-5" style="max-width: 600px;">
  <h1 class="display mb-0 mt-5">Frequently Asked Questionss</h1>
  <hr class="w-25 mx-auto bg-primary">
</div>

<div class="container">
  <div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
      <h2 class="my-4 text-center"></h2>
      <div class="accordion">

        <div class="accordion-item">
          <button id="accordion-button-1" aria-expanded="false">
            <span class="accordion-title">What is WinningWavez?</span>
            <span class="icon" aria-hidden="true"></span>
          </button>
          <div class="accordion-content">
            <p>
              Winning wavez is an Ed-tech company that provides online courses focused on developing the skills and
              knowledge required for individuals to become successful entrepreneurs and investors.
            </p>
          </div>
        </div>

        <div class="accordion-item">
          <button id="accordion-button-2" aria-expanded="false">
            <span class="accordion-title">Which courses winning wavez offer?</span>
            <span class="icon" aria-hidden="true"></span>
          </button>
          <div class="accordion-content">
            <p>
              Welcome to WinningWavez, a transformative educational hub crafted for both beginners and seasoned
              individuals. Immerse yourself in expert-designed courses covering a spectrum of skills, including
              marketing, sales, personal development, web development, online earning strategies, digital marketing,
              mobile video editing, diverse earning sources, and strategic trading insights. Our platform offers a
              comprehensive and interactive learning experience tailored for students who are eager to develop practical
              knowledge and skills. Benefit from expert guidance, apply your learning through hands-on projects, and
              stay up-to-date with regularly updated content. Join WinningWavez and embark on a journey of continuous
              evolution toward a prosperous future
            </p>
          </div>
        </div>

        <div class="accordion-item">
          <button id="accordion-button-3" aria-expanded="false">
            <span class="accordion-title">How enroll in our courses?</span>
            <span class="icon" aria-hidden="true"></span>
          </button>
          <div class="accordion-content">
            <p>Follow the steps to enroll in our courses.</p>
            <p>1. Go to WinningWavez Website</p>
            <p>2. Click on View More</p>
            <p>3. Fill in the asked details</p>
            <p>4. Choose your favorite course</p>
          </div>
        </div>

        <div class="accordion-item">
          <button id="accordion-button-4" aria-expanded="false">
            <span class="accordion-title">Will I get the completion certificate?</span>
            <span class="icon" aria-hidden="true"></span>
          </button>
          <div class="accordion-content">
            <p>
              Yes, you will get the completion certificate.
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-1"></div>
  </div>
</div>

<!-- faq end -->


<!-- counter -->
<section class="text-center mx-auto mb-5 mt-5" style="max-width: 600px;">
  <h1 class="display mb-0 mt-5">Our Achievements</h1>
  <hr class="w-25 mx-auto bg-primary">
</section>

<div class="fun-facts">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="wrapper my-5">
          <div class="row">
            <div class="col-lg-3">

              <div class="counter">
                <p class="count-text text-center mb-3">Courses</p><br>
                <h2 class="timer count-title count-number" data-to="10" data-speed="1000"></h2>

              </div>
            </div>
            <div class="col-lg-3">
              <div class="counter">
                <p class="count-text  text-center mb-3">Live Trainings</p><br>
                <h2 class="timer count-title count-number" data-to="60" data-speed="1000"></h2>

              </div>
            </div>
            <div class="col-lg-3">
              <div class="counter">
                <p class="count-text  text-center mb-3">Enrolled Learners</p>
                <h2 class="timer count-title count-number" data-to="720" data-speed="1000"></h2>

              </div>
            </div>
            <div class="col-lg-3">
              <div class="counter percent">
                <p class="count-text  text-center mb-3">Satisfaction Rate</p><br>
                <h2 class="timer count-title percentage" data-to="99" data-speed="1000"></h2>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- conunter end -->


<!-- Testimonial -->
<div class="text-center mx-auto mb-5 mt-5" style="max-width: 600px;">
  <h1 class="display mb-0 mt-5">Testimonials</h1>
  <hr class="w-25 mx-auto bg-primary">
</div>

<div class="container my-5">
  <section id="testim" class="testim">

    <!--         <div class="testim-cover"> -->
    <div class="wrap">

      <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
      <span id="left-arrow" class="arrow left fa fa-chevron-left "></span>
      <ul id="testim-dots" class="dots" style="margin-bottom: -45px">
        <li class="dot active"></li><!--
                    -->
        <li class="dot"></li><!--
                    -->
        <li class="dot"></li><!--
                    -->
        <li class="dot"></li><!--
                    -->
        <li class="dot"></li><!--
                    -->
        <li class="dot"></li><!--
                    -->
        <li class="dot"></li>
      </ul>
      <div id="testim-content" class="cont">

        <div class="active">
          <div class="img"><img src="https://winningwavez.com/assets/images/people3.jpg" alt=""></div>
          <h2>Soumya Ranjan Acharya</h2>
          <p>I want to say that Winning Wavez is the best
            company in the whole Ed-tech industry.l learn so many digital skills from Winning Wavez, now i monitize my
            skills & Earn revenue from my social media only because of Winning Wavez So thanks So Much Winning Wavez &
            Bikash Sir.</p>
        </div>

        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people1.jpg" alt=""></div>
          <h2>Soubhagya Sahoo</h2>
          <p>
            I am glad to share my experience with you
            regarding this platform. Here, I have been taught to create enormous opportunities. The lifetime access to
            quality content made me learn everything quickly. It's the best decision of my life.
          </p>
        </div>

        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people2.jpg" alt=""></div>
          <h2>Subhasis Swain</h2>
          <p>This platform provided me so many skills through its courses. These skills gave me a lot of benefits in my
            job. Here I got a growth opportunity and learned communication skills. Thank you so much for changing my
            life</p>
        </div>

        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people4.jpg" alt=""></div>
          <h2>Namrata Ojha</h2>
          <p>Now, I understood the advantages of Digital
            Marketing to create my brand. It has created as power to grow forward. When I begins my journey, I had
            nothing. Here, I learned quickly. Indeed, it is one of the best decisions in my life.</p>
        </div>

        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people7.jpg" alt=""></div>
          <h2>Bibhash Ranjan Panda </h2>
          <p>Here, you can learn Ads Marketing, Social Media Marketing, Public Dealing, and Communication skills. So, I
            recommend you to learn and generate higher revenue after learning through this platform. I highly recommend
            everyone to explore it .</p>
        </div>
        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people6.jpg" alt=""></div>
          <h2>Soumya Shree Barik </h2>
          <p>Here, I got ample opportunities for learning and growth. I am extremely happy with my experience so far.
            The trainers are highly experienced and knowledgeable. The learning environment as also supportive and
            encouraging.
          </p>
        </div>
        <div>
          <div class="img"><img src="https://winningwavez.com/assets/images/people5.jpg" alt=""></div>
          <h2>Kumkum Ransingh</h2>
          <p>I was struggling to make extra income, then I found Winning Wavez Private Limited. I started learning
            valuable courses. The digitalskills provided by it have changed my life. Thank you so much Winning Wavez
            Private Limited for this life-changing opportunity.</p>
        </div>

      </div>

    </div>

  </section>
</div>

<script src="https://use.fontawesome.com/1744f3f671.js"></script>




<!-- testimonials end-->

<?php include "footer.php" ?>
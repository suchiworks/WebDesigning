<?php include "header.php" ?>

<section class="policy" id="top">
    <img src="assets/images/privacy-policy.jpg" width="100%" height="400px" alt="refund">
</section>
<!-- <section class="meetings-page" id="meetings"> -->

<section class="refund">
    <div class="container">
        <h4>Privacy Policy</h4>
        <p>We value your trust. In order to honour that trust, WinningWavez adheres to ethical standards in gathering,
            using, and safeguarding any information you provide. WinningWavez, is a leading edtech company, incorporated
            in India, for imparting learning. This privacy policy governs your use of the website , www.winningwavez.in
            ('Website') and the other associated products, websites and services managed by the Company. Please read
            this privacy policy ('Policy') carefully before using the , Website, our services and products, along with
            the Terms of Use ('ToU') provided on the Website. Your use of the Website, or services in connection with
            the Website or products ('Services'), or registrations with us through any modes or usage of any products
            including , tablets or other storage/transmitting device shall signify your acceptance of this Policy and
            your agreement to be legally bound by the same. If you do not agree with the terms of this Policy, do not
            use the Website, Application our products or avail any of our Services.</p>
       

        <h4>User Provided Information</h4>
        <p>The Application/Website/Services/products obtains the information you provide when you register for the
            Website or Services or products. When you register with us, you generally provide (a) your name, a ge, email
            address, location, phone number, password and your ward's educational interests; (b) transaction-related
            information, such as when you make purchases, respond to any offers, or download or use applications from
            us; (c) information you provide us when you contact us for help; (d) information you enter into our system
            when using the Wey/Services/products, such as while asking doubts, participating in discussions and taking
            tests. The said information collected from the users could be categorized as “Personal Information”,
            “Sensitive Personal Information” and “Associated Information”. Personal Information, Sensitive Personal
            Information and Associated Information (each as individually defined under this Information Technology
            (Reasonable security practices and procedures and sensitive personal data or information) Rules, 2011 (the
            “Data Protection Rules”)) shall collectively be referred to as 'Information' in this Policy. We may use the
            Information to contact you from time to time, to provide you with the Services, important information,
            required notices and marketing promotions. We will ask you when we need more information that personally
            identifies you (personal information) or allows us to contact you. We will not differentiate between who is
            using the device to access the Website or Services or products, so long as the log in/access credentials
            match with yours. In order to make the best use of the Website/Services/products and enable your Information
            to be captured accurately on the Website/Services/products, it is essential that you have logged in using
            your own credentials. We will, at all times, provide the option to you to not provide the Personal
            Information or Sensitive Personal Information, which we seek from you. Further, you shall, at any time while
            using the Application/Services/products, also have an option to withdraw your consent given earlier to us to
            use such Personal Information or Sensitive Personal Information. Such withdrawal of the consent is required
            to be sent in writing to us at the contact details provided in this Policy below. In such event, however,
            the Company fully reserves the right not to allow further usage of the Application or provide any
            Services/products thereunder to you.</p>

        <h4>Automatically Collected Information</h4>
        <p>We collect information you provide directly to us. For example, we collect information when you create an
            account, participate in any interactive features of the Services, participate in a survey, contest or
            promotion, subscribe to a newsletter or email list, purchase, access or download content through the
            Services, refer others to the Services, apply for a job, interact with us via third party social media
            sites, request customer support or otherwise communicate with us. The types of information we may collect
            include your name, email address, username, password, postal address, phone number, language preference,
            payment information (such as your credit or debit card), and any other information you choose to provide. In
            some cases, we also may collect information you provide about others. For example, if you refer a friend or
            family member to the Services, we may collect certain information such as the email address of the
            recipient. Information We Collect Automatically When You Use the Services</p>


        <h4>When you access or use our Services, we automatically collect information about you, including:</h4>
        <p>Log Information: We log information about your use of the Services, including your Internet Protocol ("IP")
            address, web request, access times, pages viewed, content you purchase, access, download or burn, web
            browser, links clicked, and the page you visited before navigating to the Services. Device Information: We
            collect information about the mobile device or computer you use to access our Services, including the
            hardware model, operating system and version, unique device identifiers and mobile network information.
            Location Information: We may collect information about the location of your device when you access or use
            our Services or otherwise consent to the collection of this information. For more information, please see
            "Your Choices" below. Information Collected by Cookies and Other Tracking Technologies: Cookies are a small
            piece of software code that a website sends to your browser when you access information at that site. This
            site uses cookies to help us to improve our Services and your experience, see which areas and features of
            our Services are popular, and count visits. We may also collect information using web beacons (also known as
            "tracking pixels"). Web beacons are electronic images that may be used in our Services or emails and help
            deliver cookies, count visits, understand usage and campaign effectiveness, and determine whether an email
            has been opened and acted upon. For more information about cookies, and how to disable them, please see
            "Your Choices" below. Information We Collect From Other Sources</p>

        <p>We also may obtain information from other sources and combine that with information we collect through the
            Services. For example, if you create an account using your credentials from a third-party social media site,
            we will have access to certain information from that site, such as your name and account information, in
            accordance with the authorization procedures determined by such third-party social media sites.</p>

        <h4>Use of Information</h4>

        <p>WinningWavez does not sell its users’ personal information or personal data. We may use information about you
            for various purposes, including:</p>
        <p>Provide, maintain, and improve our Services. Provide and deliver the services you request, process
            transactions and send you related information, including confirmations and invoices. Send you technical
            notices, updates, security alerts, and support and administrative messages. Respond to your comments,
            questions and requests, and provide customer service. Communicate with you about products, services, offers,
            promotions, and events offered by WinningWavez and others, and provide news and other information we think
            will be of interest to you. Monitor and analyze trends, usage, and activities in connection with our
            Services. Personalize and improve the Services, and provide advertisements, content or features that match
            your interests and preferences. Process and deliver contest or promotion entries and rewards. Link or
            combine with information we receive from others to help understand your needs and to provide you with better
            service. Carry out the Advertising and Analytics Services (described below). Carry out any other purpose for
            which the information was collected. Social Sharing Features</p>

        <p>The Services may offer social sharing features and other integrated tools (such as the Facebook "Like"
            button), which let you share actions you take on the Services with other media, and vice versa. The use of
            such features enables the sharing of information with your friends or the public, depending on the settings
            you establish through the Services and with the entity that provides the social sharing feature.</p>

        <h4>Advertising and Analytics Services</h4>
        <p>We may allow others to serve you advertisements across the Internet and to provide analytics services. These
            entities may use cookies, web beacons and other technologies to collect information about your use of the
            Services and other websites. This information may be used by WinningWavez and others to, among other things,
            analyze and track data, determine the popularity of certain content, deliver advertising and content
            targeted to your interests on our Services and other websites and better understand your online activity.
        </p>

        <p>We or a data partner we have engaged may collect, store and share a unique identifier matched to your mobile
            device, in order to deliver customized ads or content while you use applications or surf the internet, or to
            seek to identify you in a unique manner across other devices or browsers. In order to customize these ads or
            content, we or a data partner may connect and/or share aggregated or de-identified demographic or other data
            you voluntarily have submitted to us, or data collected from you, which cannot reasonably be used to
            identify you.</p>

        <h4>Security</h4>

        <p>WinningWavez takes reasonable measures to help protect information about you from loss, theft, misuse, and
            unauthorized access, disclosure, alteration and destruction.</p>

        <h4>Your Choices</h4>
        <p>You may update, correct or delete your account information at any time by logging into your online account or
            by contacting us through contact information provided at our official website. If you wish to deactivate
            your online account, you may contact us through contact information provided at our official website. Please
            note, however, that we may retain certain information as required by law or for legitimate business
            purposes. We also may retain cached or archived copies of information about you for a certain period of
            time.</p>

        <h4>Device and Location Information</h4>
        <p>Certain features of the Services may require access to your device's native address book application. By
            downloading and launching our mobile application that collects location information, you consent to
            applications' collection of this information. Note that you can revoke your consent at any time and prevent
            us from accessing your address book application by changing your preferences on your mobile device. If you
            do so, certain features of our mobile applications may no longer function.</p>

        <h4>Cookies</h4>
        <p>Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your
            browser to remove or reject browser cookies. Removing or rejecting browser cookies does not necessarily
            affect third-party flash cookies used in connection with our Services. Please note that if you choose to
            remove or reject cookies, this could affect the availability and functionality of our Services.</p>



        <h4>Promotional Communications</h4>
        <p>You may opt out of receiving promotional communications from WinningWavez by following the instructions in
            those communications or by logging into your online account and updating your preferences. If you opt out,
            we may still send you non-promotional communications, such as those about your account or our ongoing
            business relations.</p>


        <h4>Push Notifications/Alerts</h4>
        <p>your consent, we may send push notifications or alerts to your mobile device. You can deactivate these
            messages at any time by changing the notification settings on your mobile device.</p>

        <p>This Agreement, together with our Terms of Use, EULA and any other rules, regulations, procedures and
            policies which are hereby incorporated or prescribed or amended on any future date, herein by this
            reference, constitutes the entire agreement between you and WinningWavez with respect to the Service.
            WinningWavez reserves the right to modify the policies on any future date and shall post any revisions on
            this page. You are advised to visit these privacy policies regularly to stay updated on the currently
            applicable policies for your use of the Service, Software, website and Content.</p>

        <p>No delay or failure to take action under this Agreement shall constitute any waiver by WinningWavez of any
            provision of this Agreement.</p>

        <p>If you have any questions about this Privacy Policy, you may contact us through contact information provided
            at our official website or mobile application.</p>



    </div>
</section>




<?php include "footer.php" ?>
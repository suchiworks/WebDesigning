<?php include "header.php" ?>
<section class="meetings-page" id="meetings">


    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <img src="assets/images/book10.jpg" style="margin-top: 100px" height= "444px" alt="">
            </div>
            <div class="col-lg-7">
                <div class="audit">
                    <center>
                        <h1>What you'll learn</h1>
                        <hr>
                    </center>
                    <ul>
                        <li>○
                            Unlock the art of mobile video editing with our comprehensive course on the DETAILED VN app!
                            Dive into a detailed overview that guides you through every facet of video editing, from
                            shooting to splitting and merging videos seamlessly. Learn the secrets of speed editing to
                            enhance the pace and impact of your content. Discover the skill of effortlessly editing text
                            onto your videos, adding a dynamic and personalized touch to your creations.
                        </li><br>
                        <li>○
                            But that's not all – this course goes beyond the basics. Uncover the strategies and
                            techniques
                            to craft captivating videos specifically tailored for YouTube Shorts, leveraging the
                            platform's
                            unique features to make your content stand out. Delve into the world of Instagram Reels and
                            master the art of creating engaging, short-form videos that capture attention and resonate
                            with
                            your audience.
                        </li><br>
                        <li>○
                            Whether you're a budding content creator or a seasoned videographer, this course equips you
                            with
                            the skills to elevate your mobile video editing game. Join us and transform your videos into
                            compelling stories that shine on platforms like YouTube and Instagram!
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>



    <?php include "footer.php" ?>
<?php include "header.php" ?>

<section class="policy" id="top">
    <img src="assets/images/refund_policy.jpg" width="100%" height="400px" alt="refund">
</section>
<!-- <section class="meetings-page" id="meetings"> -->

<section class="refund">
    <div class="container">
        <h4>Refund Policy</h4>
       <ul>
        <li><strong>1.</strong>&nbsp;If cancellation is made within 24 hours after registration, a refund can be requested, but it is subject to certain deductions.</li>
        <li><strong>2.</strong>&nbsp; Deductions include a Payment Gateway Fee of 5% and a Processing Fee of 10% of the paid amount.</li>
        <li><strong>3.</strong>&nbsp;The refund will be processed to the original payment mode only.</li>
        <li><strong>4.</strong>&nbsp;The turnaround time for the refund is 7-10 working days.</li>
        <li><strong>5.</strong>&nbsp;During peak times (holidays, special events, etc.), it can take longer than normal to process.</li>
       </ul>
       <p><span>Note:</span> If the reason is not valid, you will not be eligible for a refund.</p>

       <h4>Process for Refund Request</h4>
       <p>To request a refund, an individual must send an Email to <a href="#">support@winningwavez.com </a>from their registered email address with the following details:</p>
       <ul>
        <li><strong>1.</strong>&nbsp;Full Name:</li>
        <li><strong>2.</strong>&nbsp; Registered Email ID:</li>
        <li><strong>3.</strong>&nbsp;Registration Date:</li>
        <li><strong>4.</strong>&nbsp;Valid reason for Refund:</li>
        <li><strong>5.</strong>&nbsp;Screenshot of payment with Date and Time:</li>
        <p>(You must have received an email/message when you paid)</p>
       </ul>
       <p><span>Note:</span> refund requests will not be processed without the above-shared details.</p>

       <h4>Refund CancellationPolicy</h4>
       <p>Once a customer cancels their refund request, the claim cannot be re - opened or undone in the future.

</p>

    </div>
</section>




    <?php include "footer.php" ?>
   

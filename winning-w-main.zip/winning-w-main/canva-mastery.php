<?php include "header.php" ?>
<section class="meetings-page" id="meetings">


    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <img src="assets/images/book2.jpg" style="margin-top: 100px" height= "480px" alt="">
            </div>
            <div class="col-lg-7">
                <div class="audit">
                    <center>
                        <h1>What you'll learn</h1>
                        <hr>
                    </center>
                    <ul>
                        <li>○
                        Embark on a creative journey with our comprehensive course on image creation and editing, where you'll discover the power of crafting stunning, high-resolution visuals without breaking the bank. From desktop wallpapers to phone backgrounds (both homescreen and lockscreen), learn to generate eye-catching images that captivate and inspire.
                        </li><br>
                        <li>○
                        Unlock the world of graphic design as you delve into logo creation, suitable for both personal and commercial purposes. Explore the art of resume design, ensuring your job applications stand out with easy-to-read and visually appealing resumes.
                        </li><br>
                        <li>○
                        Dive into the realm of social media aesthetics with a focus on Instagram stories and posts, including video content. Uncover valuable tips and tricks within Canva's website, tapping into its full potential for your creative projects.
                        </li><br>
                        <li>○ 
                            But that's not all – this course extends beyond static visuals. Master the art of presentations, learning to create compelling slides and effectively communicate your ideas. Take it a step further by recording your presentations with a webcam for a polished, professional touch.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>



    <?php include "footer.php" ?>
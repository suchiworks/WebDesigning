<?php include "header.php" ?>

<div class="page-heading ">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <span class="breadcrumb"><a href="index.php">Home</a> / Courses</span>
          <h3>Courses</h3>
        </div>
      </div>
    </div>
  </div>
  

  <div class="section properties" style="margin-bottom:60px;">
    <div class="container">
      <ul class="properties-filter">
        <li>
          <a class="is_active" href="#!" data-filter="*">Show All</a>
        </li>
        <li>
          <a href="#!" data-filter=".adv">Pre Win</a>
        </li>
        <li>
          <a href="#!" data-filter=".str">Win Lite</a>
        </li>
        <li>
          <a href="#!" data-filter=".rac">Ultra Win</a>
        </li>
        <li>
          <a href="#!" data-filter="*">Win master</a>
        </li>
      </ul>
      <div class="row properties-box">
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 adv str rac">
          <div class="item" id="item-bg">
            <a href="mobile-vedio-editing"><img src="assets/images/course1.jpg" alt=""></a>
            <hr>
            <span class="category">Mobile Vedio Editing</span>
            <h6> 10 hours</h6>
            <h4><a href="mobile-vedio-editing"></a></h4>
            
            <div class="main-button">
              <a href="mobile-vedio-editing">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 adv str rac">
          <div class="item" id="item-bg">
            <a href="canva-mastery"><img src="assets/images/course2.jpg" alt=""></a>
            <hr>
            <span class="category">Canva Mastery</span>
            <h6> 10 Hours</h6>
            <h4><a href="canva-mastery"></a></h4>
  
            <div class="main-button">
              <a href="canva-mastery">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 adv str rac">
          <div class="item" id="item-bg">
            <a href="sales-closing-mastery"><img src="assets/images/course3.jpg" alt=""></a>
            <hr>
            <span class="category">Sales Closing Mastery</span>
            <h6> 10 Hours</h6>
            <h4><a href="sales-closing-mastery"></a></h4>
           
            <div class="main-button">
              <a href="sales-closing-mastery">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 str rac ">
          <div class="item" id="item-bg">
            <a href="spoken-english"><img src="assets/images/course4.jpg" alt=""></a>
            <hr>
            <span class="category">Spoken English</span>
            <h6> 10 Hour</h6>
            <h4><a href="spoken-english"></a></h4>
            
            <div class="main-button">
              <a href="spoken-english">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 rac str">
          <div class="item" id="item-bg">
            <a href="ms-excel"><img src="assets/images/course5.jpg" alt=""></a>
            <hr>
            <span class="category">Ms Excel</span>
            <h6>9 Hour</h6>
            <h4><a href="ms-excel"></a></h4>
            
            <div class="main-button">
              <a href="ms-excel">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6 rac ">
          <div class="item" id="item-bg">
            <a href="instagram-grow"><img src="assets/images/course6.jpg" alt=""></a>
            <hr>
            <span class="category">instagram Grow</span>
            <h6>10 Hour</h6>
            <h4><a href="instagram-grow"></a></h4>
            
            <div class="main-button">
              <a href="instagram-grow">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6  align-self-center  mb-30 properties-items col-md-6 rac ">
          <div class="item" id="item-bg">
            <a href="success-in-business"><img src="assets/images/course7.jpg" alt=""></a>
            <hr>
            <span class="category">Success in Online Business</span>
            <h6>10 Hour</h6>
            <h4><a href="success-in-business"></a></h4>
           
            <div class="main-button">
              <a href="success-in-business">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6  ">
          <div class="item" id="item-bg">
            <a href="coding"><img src="assets/images/course8.jpg" alt=""></a>
            <hr>
            <span class="category">Coding</span>
            <h6>10 Hour</h6>
            <h4><a href="coding"></a></h4>
            
            <div class="main-button">
              <a href="coding">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 align-self-center mb-30 properties-items col-md-6  ">
          <div class="item" id="item-bg">
            <a href="html"><img src="assets/images/course9.jpg" alt=""></a>
            <hr>
            <span class="category">Html</span>
            <h6>10 Hour</h6>
            <h4><a href="#"></a></h4>
           
            <div class="main-button">
              <a href="html">View More</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6  mb-30 properties-items col-md-6 item-last" style="left:0px">
          <div class="item" id="item-bg">
            <a href="youtube-success-blueprint"><img src="assets/images/course10.jpg" alt=""></a>
            <hr>
            <span class="category">Youtube Success Blueprint</span>
            <h6>10 Hours</h6>
            <h4><a href="#"></a></h4>
            
            <div class="main-button">
              <a href="youtube-success-blueprint">View More</a>
            </div>
          </div>
        </div>
        
      </div>
      <div class="row">
        <div class="col-lg-12">
          <ul class="pagination">
            <li><a href="#">1</a></li>
            <li><a class="is_active" href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">>></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <?php include "footer.php" ?>

<?php include "header.php" ?>


<div class="page-heading">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <span class="breadcrumb"><a href="index.php">Home</a> / Contact Us</span>
        <h3>Contact Us</h3>
      </div>
    </div>
  </div>
</div>

<div class="contact-page section" style="margin-bottom: 60px;padding: 9px;">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="section-heading">
          <h6>| Contact Us</h6>
          <h2>Get In Touch</h2>
        </div>
        <p>Such an academy might offer online courses, workshops, seminars, or even certification programs to help
          individuals acquire and improve their digital skills .
        <br>We love hearing from you! Whether you have a question about our products, need assistance with an order, or simply want to say hello, we're here to help.</p>
        <div class="row">
          <div class="col-lg-10">
            <div class="item phone">
              <img src="https://t4.ftcdn.net/jpg/03/94/13/75/360_F_394137592_TrU1phy53zBu1BwK4d3nFQC1i9IKoy08.jpg"
                alt="" style="max-width: 31px;">
              <h6>
                Bhubaneswar, Odisha<br><span>Address</span></h6>
            </div>
          </div>
          <div class="col-lg-2"></div>
          <div class="col-lg-10">
            <div class="item phone">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiqcDCiA79Uhw7HovjJWzt2DAYm5m4OgAdoTpCxTQHqg&s"
                alt="" style="max-width: 38px;">
              <h6>9668740823<br><span>Phone Number</span></h6>
            </div>
          </div>
          <div class="col-lg-2"></div>
          <div class="col-lg-10">
            <div class="item email">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTjAGYMe0P0R7NlPX3TMDgMw2hudZBSgwSazmix2WeTw&s"
                alt="" style="max-width: 38px;">
              <h6>support@winningwavez.com<br><span>Business Email</span></h6>
            </div>
          </div>
          <div class="col-lg-2"></div>
        </div>
      </div>
      <div class="col-lg-5">
        <form id="contact-form" action="" method="post">
          <div class="row">
            <div class="col-lg-12">
              <fieldset>
                <label for="name">Full Name</label>
                <input type="name" name="name" id="name" placeholder="Your Name..." autocomplete="on" required>
              </fieldset>
            </div>
            <div class="col-lg-12">
              <fieldset>
                <label for="email">Email Address</label>
                <input type="text" name="email" id="email" pattern="[^ @]@[^ @]" placeholder="Your E-mail..."
                  required="">
              </fieldset>
            </div>
            <!-- <div class="col-lg-12">
              <fieldset>
                <label for="subject">Subject</label>
                <input type="subject" name="subject" id="subject" placeholder="Subject..." autocomplete="on">
              </fieldset>
            </div> -->
            <div class="col-lg-12">
              <fieldset>
                <label for="message">Message</label>
                <textarea name="message" id="message" placeholder="Your Message"></textarea>
              </fieldset>
            </div>
            <div class="col-lg-12">
              <div class="icon-button">
                <a href="property-details.html"><i class="fa fa-calendar"></i>Send Message</a>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div class="col-lg-1"></div>
    </div>
  </div>
</div>


<?php include "footer.php" ?>
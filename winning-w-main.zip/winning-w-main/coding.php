<?php include "header.php" ?>
<section class="meetings-page" id="meetings">


    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <img src="assets/images/book8.jpg" style="margin-top: 100px" height= "496px" alt="">
            </div>
            <div class="col-lg-7">
                <div class="audit">
                    <center>
                        <h1>What you'll learn</h1>
                        <hr>
                    </center>
                    <ul>
                        <li>○
                            Embark on a creative journey with our comprehensive course on image creation and editing,
                            where you'll discover the power of crafting stunning, high-resolution visuals without
                            breaking the bank. From desktop wallpapers to phone backgrounds (both homescreen and
                            lockscreen), learn to generate eye-catching images that captivate and inspire.
                        </li><br>
                        <li>○

                            Enhance your productivity with modules on creating a personalized productivity planner.
                            Explore the concept of a brand kit and content planner to maintain a cohesive and engaging
                            online presence. Finish off with insights into designing business cards that leave a lasting
                            impression.
                        </li><br>
                        <li>○
                            Dive into the realm of social media aesthetics with a focus on Instagram stories and posts,
                            including video content. Uncover valuable tips and tricks within Canva's website, tapping
                            into its full potential for your creative projects.
                        </li><br>
                        <li>○
                            Navigate the world of social media marketing with lessons on creating captivating Instagram
                            stories, YouTube thumbnails, and video ads. Gain practical skills in invoice generation,
                            ensuring your business transactions are streamlined and professional.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>



    <?php include "footer.php" ?>
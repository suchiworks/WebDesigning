<section class="bg test-black ">
  <footer class="footer-d">
    <div class="container">
      <div class="row" style="margin-left:25px;">
        <div class="footer-col sp">
          <img src="assets/images/logo-ww.jpg" width="50%" height="100px" alt="logo" style=margin-top:-8px>
          <ul>
            <li><a href="#"><i class="bi bi-geo-alt-fill"></i>Bhubaneswar, Odisha</a></li>
            <li><a href="#"><i class="bi bi-envelope-fill"></i>support@winningwavez.com</a></li>
            <li><a href="#"><i class="bi bi-telephone"></i>+91 9668740823</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Get Help</h4>
          <ul>
            <li><a href="about-us">About Us</a></li>
            <li><a href="#">Documents</a></li>
            <li><a href="#">Login</a></li>
            <li><a href="#">Register</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Digital Contents</h4>
          <ul>
            <li><a href="#">Download</a></li>
            <li><a href="courses">All Courses</a></li>
            <li><a href="contact">Contact Us</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Legal Terms</h4>
          <ul>
            <li><a href="refund-policy">Refund Policy</a></li>
            <li><a href="privacy-policy">Privacy Policy</a></li>
            <li><a href="terms-conditions">Terms & Conditions</a></li>
            <li><a href="disclaimer">Disclaimer</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
</section>



<footer>
  <div class="container">
    <div class="col-lg-12 ft">
      <p style="text-align:center">COPYRIGHT ©2024 WINNINGWAVEZ.COM ALL RIGHTS RESERVED.
      Designed By
        <a href="https://www.strivingsquad.com/" target="_blank"> STRIVINGSQUAD PVT LTD</a>
      </p>
    </div>
  </div>
</footer>

<!-- Scripts -->
<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/isotope.min.js"></script>
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/counter.js"></script>
<script src="assets/js/custom.js"></script>

</body>

</html>
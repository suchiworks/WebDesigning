<?php include "header.php" ?>
<section class="meetings-page" id="meetings">


    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <img src="assets/images/book3.jpg" style="margin-top: 100px" height= "442px" alt="">
            </div>
            <div class="col-lg-7">
                <div class="audit">
                    <center>
                        <h1>What you'll learn</h1>
                        <hr>
                    </center>
                    <ul>
                        <li>○
                        Welcome to the transformative journey of mastering high-ticket sales with our comprehensive course. Elevate your sales skills and learn to close high-value deals with finesse, all without resorting to pushy tactics. This course is designed to empower you with the knowledge and mindset necessary for success in the competitive world of high-ticket sales.
                        </li><br>
                        <li>○
                        Discover counterintuitive strategies that will empower you to overcome objections seamlessly during the sales conversation. Break through limiting beliefs surrounding money and sales, unlocking your full potential to excel in the art of closing deals.
                        </li><br>
                        <li>○
                        Develop a winning sales closing master attitude that is crucial for your success in high-ticket sales. Gain valuable insights into the psychology of sales, allowing you to almost immediately convert more leads into successful sales. Take control of the sales conversation, guiding it with confidence and precision.
                        </li><br>
                        <li>○
                        Witness a tangible impact on your revenue or commissions as you implement the strategies learned in this course. Build confidence to the point where you feel unstoppable, propelling yourself towards unprecedented success in the world of high-ticket sales.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>



    <?php include "footer.php" ?>